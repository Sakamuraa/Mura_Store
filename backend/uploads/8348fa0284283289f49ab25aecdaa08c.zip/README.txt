Steam Apply Tool
===============

This tool applies manifests to your Steam games.

Instructions:
1. Place your manifest files in the same directory as this README
2. Run apply_to_steam.exe
3. Follow the on-screen instructions

For more help, visit our Discord server.

all credits go to @v80qk on discord. the database and this files. if you need support direct message me.

and if you took this file and tried putting it in ur own database do not delete this readme.