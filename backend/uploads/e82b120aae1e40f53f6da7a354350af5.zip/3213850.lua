addappid(3213850)
addappid(3213851,0,"096cd494378b8ab62d21a7eadcf9a1736f7fe130b6f9bef9d2bb894074ab1bce")
setManifestid(3213851,"1510712349922717769")

-- credits to v80qk on discord dont put on ur own bot have some shame (yk urself)